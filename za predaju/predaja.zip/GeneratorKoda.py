import pisac as PK
import operatori_asm as OP

#pocetak = "    MOVE 40000, R7\n    CALL F_MAIN\n    HALT\n"

import SemantickiAnalizator
OP.upisi_operatore()
PK.zavrsi()
#print("GOTOV")